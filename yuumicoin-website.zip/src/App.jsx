function App() {
  return (
    <div className="min-h-screen flex flex-col items-center p-4">
      <header className="text-center mt-8">
        <h1 className="text-5xl font-bold">Yuumicoin</h1>
        <p className="mt-4 text-xl">
          Backed by purrs. Powered by memes. Guided by an enchanted feline.
        </p>
        <div className="mt-6 space-x-4">
          <button className="bg-primary px-6 py-2 rounded-lg">Buy $YUUMI</button>
          <button className="bg-accent text-black px-6 py-2 rounded-lg">Join the Community</button>
        </div>
      </header>
      <img src="./images/hero.png" alt="Yuumicoin hero" className="mt-12 w-2/3 max-w-lg" />
    </div>
  );
}

export default App;